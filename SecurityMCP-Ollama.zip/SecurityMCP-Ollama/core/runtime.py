import os
import sys
from pathlib import Path
from contextlib import asynccontextmanager, AsyncExitStack
from mcp_client import MCPClient
from core.cli_chat import CliChat
from core.ollama_service import OllamaService

ROOT = Path(__file__).resolve().parent.parent


@asynccontextmanager
async def open_chat(allow_edits=False, server_scripts=()):
    async with AsyncExitStack() as stack:
        service = OllamaService(
            os.getenv("OLLAMA_MODEL", "qwen3:8b"),
            os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434"))
        stack.push_async_callback(service.close)
        env = {key: value for key, value in os.environ.items()
               if key in {"PATH", "HOME", "USERPROFILE", "SYSTEMROOT", "WINDIR",
                          "TEMP", "TMP", "TMPDIR", "LANG", "PYTHONIOENCODING"}}
        doc_client = await stack.enter_async_context(MCPClient(
            command=sys.executable, args=[str(ROOT / "mcp_server.py")], env=env))
        clients = {"documents": doc_client}
        for index, script in enumerate(server_scripts):
            clients[f"extension_{index}"] = await stack.enter_async_context(MCPClient(
                command=sys.executable, args=[str(Path(script).resolve())], env=env))
        yield CliChat(doc_client, clients, service, allow_edits=allow_edits)
