from core.tools import ToolManager


class AgentLimitError(RuntimeError):
    pass


class Chat:
    def __init__(self, model_service, clients: dict, allow_edits=False, max_rounds=8):
        self.model_service = model_service
        self.tools = ToolManager(clients, allow_edits)
        self.messages = []
        self.max_rounds = max_rounds

    async def prepare_query(self, query: str) -> list:
        return [{"role": "user", "content": query}]

    async def run(self, query: str) -> str:
        tools = await self.tools.initialize()
        # Commit only complete turns so failures cannot orphan tool calls.
        messages = [*self.messages, *await self.prepare_query(query)]
        for _ in range(self.max_rounds):
            message = await self.model_service.chat(messages, tools)
            messages.append(message)  # Preserve thinking and tool calls verbatim.
            calls = message.get("tool_calls") or []
            if not calls:
                self.messages = messages
                return message.get("content", "")
            if len(calls) > 16:
                raise AgentLimitError("Too many tools requested in one round")
            for call in calls:
                messages.append(await self.tools.execute(call))
        raise AgentLimitError("Tool-call round limit reached")
