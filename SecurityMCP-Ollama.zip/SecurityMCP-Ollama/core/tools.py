"""Translate MCP tools to Ollama functions and route validated calls."""
import asyncio
import json
import re
from jsonschema import Draft202012Validator


class ToolManager:
    def __init__(self, clients: dict, allow_edits: bool = False):
        self.clients = clients
        self.allow_edits = allow_edits
        self.routes = {}
        self.definitions = []

    async def initialize(self):
        self.routes.clear()
        self.definitions.clear()
        for index, client in enumerate(self.clients.values()):
            for tool in await client.list_tools():
                read_only = tool.name == "read_payload_contents" or (
                    tool.annotations and tool.annotations.readOnlyHint is True
                )
                if not read_only and not self.allow_edits:
                    continue
                name = (f"m{index}_" + re.sub(r"[^a-zA-Z0-9_-]", "_", tool.name))[:64]
                if name in self.routes:
                    raise ValueError("Tool names collide after normalization")
                validator = Draft202012Validator(tool.inputSchema)
                self.routes[name] = (client, tool.name, validator)
                self.definitions.append({
                    "type": "function", "function": {"name": name,
                    "description": tool.description or tool.name,
                    "parameters": tool.inputSchema,
                    },
                })
        return self.definitions

    async def execute(self, call):
        payload = {"is_error": True, "error": "Unknown or disallowed tool"}
        name = call["function"]["name"]
        route = self.routes.get(name)
        if route:
            client, mcp_name, validator = route
            try:
                args = call["function"].get("arguments", {})
                if isinstance(args, str):
                    args = json.loads(args)
                if not isinstance(args, dict) or not validator.is_valid(args):
                    raise ValueError("Invalid tool arguments")
                result = await asyncio.wait_for(client.call_tool(mcp_name, args), 30)
                if result is None:
                    payload = {"is_error": True, "error": "Empty MCP result"}
                else:
                    payload = {
                        "is_error": bool(result.isError),
                        "content": [item.model_dump(mode="json") for item in result.content],
                    }
            except (ValueError, TypeError):
                payload = {"is_error": True, "error": "Invalid tool arguments"}
            except TimeoutError:
                payload = {"is_error": True, "error": "MCP tool timed out"}
            except Exception:
                payload = {"is_error": True, "error": "MCP tool failed"}
        output = json.dumps(payload)
        if len(output) > 100_000:
            output = json.dumps({"is_error": True, "error": "Tool output exceeds limit"})
        return {"role": "tool", "tool_name": name, "content": output}
