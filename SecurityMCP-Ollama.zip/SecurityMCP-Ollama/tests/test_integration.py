import json
import sys
from types import SimpleNamespace
from unittest.mock import AsyncMock
import httpx
import pytest
from fastapi.testclient import TestClient
from mcp.types import Tool, CallToolResult, TextContent
from api import create_app
from core import runtime
from core.chat import Chat, AgentLimitError
from core.cli_chat import CliChat
from core.ollama_service import OllamaService, ModelResponseError
from core.tools import ToolManager
from mcp_client import MCPClient

TOKEN = "test-only-" + "a" * 40
AUTH = {"Authorization": f"Bearer {TOKEN}"}


def call(name="m0_read_payload_contents", arguments=None):
    return {"function": {"name": name, "arguments": arguments if arguments is not None else {"doc_id": "q3_roadmap.md"}}}


def fake_client(error=None):
    tools = [Tool(name="read_payload_contents", inputSchema={
        "type": "object", "properties": {"doc_id": {"type": "string"}},
        "required": ["doc_id"], "additionalProperties": False}),
        Tool(name="edit_payload_contents", inputSchema={"type": "object"})]
    return SimpleNamespace(list_tools=AsyncMock(return_value=tools), call_tool=AsyncMock(
        side_effect=error, return_value=CallToolResult(content=[TextContent(type="text", text="OK")])) )


@pytest.fixture
def env(monkeypatch):
    monkeypatch.setenv("SECURITYMCP_API_KEY", TOKEN)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)


def test_http_to_ollama_to_real_mcp_roundtrip(env, monkeypatch):
    requests = []

    def handle(request):
        body = json.loads(request.content)
        requests.append(body)
        assert request.url.path == "/api/chat"
        assert "authorization" not in request.headers
        assert body["stream"] is False
        assert body["messages"][0]["role"] == "system"
        assert all(t["function"]["name"] != "m0_edit_payload_contents" for t in body["tools"])
        if len(requests) == 1:
            message = {"role": "assistant", "content": "", "thinking": "test thinking",
                       "tool_calls": [call()]}
        else:
            result = body["messages"][-1]
            assert result["role"] == "tool"
            assert result["tool_name"] == "m0_read_payload_contents"
            payload = json.loads(result["content"])
            assert payload["is_error"] is False
            assert "user authentication" in payload["content"][0]["text"]
            assert body["messages"][-2]["thinking"] == "test thinking"
            message = {"role": "assistant", "content": "Security analysis completed."}
        return httpx.Response(200, json={"message": message, "done": True})

    def service(model, host):
        return OllamaService(model, client=httpx.AsyncClient(base_url=host,
            transport=httpx.MockTransport(handle)))

    monkeypatch.setattr(runtime, "OllamaService", service)
    with TestClient(create_app()) as client:
        result = client.post("/v1/chat", headers=AUTH, json={"message": "Read q3_roadmap.md"})
    assert result.status_code == 200, result.text
    assert result.json() == {"reply": "Security analysis completed."}
    assert len(requests) == 2


@pytest.mark.parametrize("header", [None, "Bearer wrong", "Basic wrong"])
def test_auth_rejects_before_model_call(env, header):
    with TestClient(create_app()) as client:
        result = client.post("/v1/chat", headers={"Authorization": header} if header else {},
                             json={"message": "hello"})
        assert result.status_code == 401


@pytest.mark.parametrize("message", ["", "   ", "x" * 32001])
def test_input_limits(env, message):
    with TestClient(create_app()) as client:
        assert client.post("/v1/chat", headers=AUTH, json={"message": message}).status_code == 422


def test_health_requires_no_paid_api_key(env):
    with TestClient(create_app()) as client:
        assert client.get("/health").json()["provider"] == "ollama"


def test_server_refuses_weak_token(monkeypatch):
    monkeypatch.setenv("SECURITYMCP_API_KEY", "weak")
    with pytest.raises(RuntimeError, match="configure.py"):
        with TestClient(create_app()):
            pass


@pytest.mark.parametrize("arguments", ["{bad", [], {"doc_id": 42}, {}])
async def test_bad_tool_args_not_dispatched(arguments):
    client = fake_client()
    manager = ToolManager({"doc": client})
    await manager.initialize()
    result = await manager.execute(call(arguments=arguments))
    assert json.loads(result["content"])["is_error"] is True
    client.call_tool.assert_not_called()


async def test_edits_require_explicit_opt_in():
    client = fake_client()
    manager = ToolManager({"doc": client})
    await manager.initialize()
    result = await manager.execute(call("m0_edit_payload_contents", {}))
    assert json.loads(result["content"])["is_error"] is True
    client.call_tool.assert_not_called()
    manager.allow_edits = True
    await manager.initialize()
    result = await manager.execute(call("m0_edit_payload_contents", {}))
    assert json.loads(result["content"])["is_error"] is False
    client.call_tool.assert_awaited_once()


async def test_tool_exception_redacted():
    manager = ToolManager({"doc": fake_client(RuntimeError("SECRET_KEY"))})
    await manager.initialize()
    result = await manager.execute(call())
    assert "SECRET_KEY" not in result["content"]
    assert json.loads(result["content"])["is_error"] is True


async def test_duplicate_names_across_servers_are_routed():
    first, second = fake_client(), fake_client()
    manager = ToolManager({"first": first, "second": second})
    await manager.initialize()
    await manager.execute(call("m1_read_payload_contents"))
    first.call_tool.assert_not_called()
    second.call_tool.assert_awaited_once()


async def test_real_mcp_resources_prompts_and_edits():
    async with MCPClient(sys.executable, [str(runtime.ROOT / "mcp_server.py")], env={}) as client:
        chat = CliChat(client, {"doc": client}, None)
        prepared = await chat.prepare_query("Summarize @q3_roadmap.md")
        assert "user authentication" in prepared[0]["content"]
        prepared = await chat.prepare_query("/security+ urgent_memo.txt")
        assert "Security Scan Report" in prepared[0]["content"]
        with pytest.raises(ValueError):
            await chat.prepare_query("/security+")
        with pytest.raises(ValueError):
            await chat.prepare_query("/security+ missing.txt")
        result = await client.call_tool("edit_payload_contents", {
            "doc_id": "q3_roadmap.md", "old_str": "user authentication", "new_str": "access control"})
        assert not result.isError
        doc = await client.read_resource("docs://documents/q3_roadmap.md")
        assert "access control" in doc and "Modified (UTC):" in doc
        result = await client.call_tool("edit_payload_contents", {
            "doc_id": "q3_roadmap.md", "old_str": "not present", "new_str": "replacement"})
        assert result.isError


async def test_loop_limit_rolls_back_history():
    service = SimpleNamespace(chat=AsyncMock(return_value={
        "role": "assistant", "content": "", "tool_calls": [call("missing", {})]}))
    chat = Chat(service, {}, max_rounds=2)
    with pytest.raises(AgentLimitError):
        await chat.run("hello")
    assert service.chat.await_count == 2
    assert chat.messages == []


@pytest.mark.parametrize("body", [
    {"message": {"role": "assistant", "content": "partial"}, "done": False},
    {"message": {"role": "assistant", "content": "partial"}, "done": True, "done_reason": "length"},
    {"message": {"role": "assistant", "tool_calls": ["invalid"]}, "done": True},
])
async def test_incomplete_or_invalid_model_response(body):
    client = httpx.AsyncClient(base_url="http://localhost:11434",
        transport=httpx.MockTransport(lambda request: httpx.Response(200, json=body)))
    service = OllamaService(client=client)
    try:
        with pytest.raises(ModelResponseError):
            await service.chat([], [])
    finally:
        await service.close()


@pytest.mark.parametrize("status, expected", [(404, "Model or endpoint"), (400, "supports tools")])
def test_ollama_error_is_actionable(env, monkeypatch, status, expected):
    def service(model, host):
        return OllamaService(model, client=httpx.AsyncClient(base_url=host,
            transport=httpx.MockTransport(lambda request: httpx.Response(status, json={"error": "private detail"}))))
    monkeypatch.setattr(runtime, "OllamaService", service)
    with TestClient(create_app()) as client:
        result = client.post("/v1/chat", headers=AUTH, json={"message": "Hello"})
        assert result.status_code == 502
        assert expected in result.json()["detail"]
        assert "private detail" not in result.text
